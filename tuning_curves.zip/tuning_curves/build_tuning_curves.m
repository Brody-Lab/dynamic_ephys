cd ~/Dropbox/spikes/bin/tuning_curves/

addpath ~/ratter/svn_papers/TimHanks/PBupsPhys/Code/
addpath ~/ratter/svn_papers/TimHanks/PBupsPhys/Code/Carlosbin
addpath ~/ratter/ExperPort/bin
addpath ~/ratter/Analysis/Pbups
addpath ~/ratter/ExperPort/MySQLUtility
addpath ~/ratter/ExperPort/Analysis
addpath ~/ratter/ExperPort/Analysis/SameDifferent/
addpath ~/ratter/ExperPort/HandleParam
addpath ~/ratter/Analysis/helpers
addpath ~/Dropbox/spikes/cell_packager_data/
addpath ~/Dropbox/spikes/bin
warning('off','MATLAB:interp1:NaNinY');
warning('off','MATLAB:divideByZero');

%% get good cells 
cell_list = dyn_cells_db('force',0);   % That has to be run once to create cell_list
region      = 'fof';
select_str  = ['strcmp(region,''' region ''') &  normmean>1'];
cellids     = cell2mat(extracting(cell_list, 'cellid', select_str));

alignment   = 'stimstart-cout-mask'; %'cpokeout'
t0s         = 0:0.025:1.9;  % triggers rebinning and recompiling
n_dv_bins   = 100;          % triggers rebinning, but not recompiling 
lag         = 0;            %0.2;
krn_width   = 0.1;
force_frdv  = 1;            % keep as one if rebinning
force_bin   = 0;
force_dv    = 1;
norm_type   = 'none';
p.mask_after_stim_firing    = 1;
p.mask_stim_firing          = 0;
p.average_a_vals            = 1;
p.average_fr                = 1;
p.min_fr_mod                = 1;
p.fit_time_sigmoid          = 0;
p.use_nresidual             = 1;
p.plot_res                  = 3;
cellid      = 17784; % good categorical cell
cellid = 18181;
% cellid = [18181 18185 17799 17784 16875 18172 17870 16847 17855]
%cellid      = 17803; 
%cellid = [-1 -2 -3 -4 -5];

find_cells = 0;
if find_cells
    good_cells = zeros(size(cellids));
    for i=1:length(cellids)
    try
    results     = dyn_fr_dv_map(cellids(i), t0s, n_dv_bins, p,'lag', lag, 'krn_width', krn_width, 'alignment', alignment, 'var_weight', false, 'force_frdv',force_frdv,'force_bin',force_bin,'force_dv', force_dv,'norm_type',norm_type);
    good_cells(i) = true;
    catch
    end
    close all;
    end
else
    load('good_cells_10_18_2018')
    results     = dyn_fr_dv_map(cellids(logical(good_cells)), t0s, n_dv_bins, p,'lag', lag, 'krn_width', krn_width, 'alignment', alignment, 'var_weight', false, 'force_frdv',force_frdv,'force_bin',force_bin,'force_dv', force_dv,'norm_type',norm_type);
end

% debug with 18181
results = compute_variance_explained(results, 18181)
figure; hold on;
celldex = find(results.cellid == 18181);
%celldex = 2;
plot_cell(results, results.cellid(celldex));
figure; plot(results.t0s, results.frm_time(:,celldex), 'k');
figure; plot(results.t0s, results.var_explained(:,celldex),'r')

%%

results = decompose_tuning_curves(results);
plot_decomposition_analysis(results)
a


