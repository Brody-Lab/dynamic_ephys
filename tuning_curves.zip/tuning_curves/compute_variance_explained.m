function [results] = compute_variance_explained(results, cellids)

    % If we weren't given a list of cells, compute the variance explained for all of them
    if nargin ==  1
        cellids = results.cellid; 
    end
    if ~isfield(results, 'var_explained')
        results.var_explained = NaN(size(results.frm_time));
    end

    % Iterate through list of cells, and compute the variance explained
    for i=1:length(cellids)
%    try
        results = compute_variance_explained_single(results, cellids(i));
%    catch me
%        disp(me)
%    end
    end
end


function [results] = compute_variance_explained_single(results, cellid)
    % For each trial I need 
    %   actual r(t)
    %   a(t)
    %   model predicted R = r(a,t)    
    
    % to get r(a,t), load from results matrix 
    celldex = find(results.cellid == cellid);
    if isempty(celldex)
        error('Couldnt find cell in cellid list')   
    end
    if isfield(results, 'tuning_cell')
        fga = results.tuning_cell(:,:,celldex);
    else
        error('Couldnt find tuning curve, do you want to use the default fga_cell?')
    end
   
    % to get a(t), get cellid/sessid, then load model_mean
    data    = dyn_cell_packager(cellid);
    sessid  = data.sessid; 
    load(['/home/alex/Dropbox/spikes/model/model_mean_' num2str(sessid) '.mat'])
    % Need to filter trials from model to match data variable
    p.reload    = 0;
    p.ratname   = data.ratname;
    [~, vec_data, ~,~] = get_behavior_data('/home/alex/Dropbox/spikes/data/', data.cellid, data.sessid,p);
    model_mean = model_mean(vec_data.good);

    % to get r(t), I need to determine the alignment index
    alignment = 'stimstart-cout-mask';
    [align_strs, align_args] = align_LUT;
    align_ind = strmatch(alignment,align_strs,'exact');
    fr_all = data.frate{align_ind}; 
    ft = data.frate_t{align_ind};
    
    % compute model predicted R via r(a,t)
    R   = nan(size(fr_all));
    Rm  = nan(size(fr_all));
    t0s = results.t0s;
    if min(diff(t0s)) < min(diff(ft))
        error('Time bins for tuning curves are smaller than firing rate smoothed vector. Recompute firing rate.')
    end
    % Check to see if the time bins requested for the tuning curve extend beyond the firing rate vector
    if t0s(end) > ft(end)
        error('The last time point is beyond the firing rate time points. Decrease the time bins t0s, or recompute the firing rate')
    end
    

    % iterate through trials
    for i=1:size(R,1)
        fr = fr_all(i,:);
        t = model_mean(i).T;
        % iterate through timepoints
        for j=1:length(t0s);       
            t0 = t0s(j);
            t0_durs     = diff(t0s);
            if j == numel(t0s)
                this_dur    = 0;
            else
                this_dur    = t0_durs(j);
            end
            if j > 1
                last_dur = t0_durs(j - 1);
            else
                last_dur = 0;
            end
            if (this_dur/2 + t0) > ft(find(~isnan(fr),1,'last'))
                this_dur = 2*(ft(find(~isnan(fr),1,'last')) - t0);
            end
            all_time_indexes = t > (t0-last_dur/2) & t < (t0 + this_dur/2);
            mean_aval = mean(model_mean(i).mean(all_time_indexes));
            adex = bin_aval(results.dv_axis,mean_aval);
 
            % need to take mean firing rate within each time bin
            r0_mesh = interp1(ft, fr, [t0-last_dur/2, t0, t0+this_dur/2]);
            r0      = mean(r0_mesh);% The mean firing rate during the time window
        
            % make sure you mask after stimulus firing
            include_fr = ~isnan(r0) & (t(end) -t0  > 0);
            if include_fr
                R(i,j)  = r0; % store raw firing rate
                Rm(i,j) = fga(j,adex);
            end
        end
    end

    % compute variance explained
    Rmean = nanmean(R,1);
%    total_var = nanmean((R-Rmean).^2,1);
%    model_var = nanmean((R-Rm).^2,1);
    total_var = nanvar(R-Rmean,1);
    model_var = nanvar(R-Rm,1);
    pVar = 1 - model_var./total_var;
    keyboard
%    figure; hold on;
%    plot(total_var,'k')
%    plot(total_var2,'k--')
%    plot(model_var,'r')
%    plot(model_var2,'r--')

    figure; 
    subplot(2,3,1); hold on;
    plot(R')
    plot(Rmean, 'k','linewidth',2)
    x = ylim();
    subplot(2,3,2); hold on;
    plot(Rm')
    plot(Rmean, 'k','linewidth',2)
    ylim(x)
    subplot(2,3,3); hold on;
    plot(total_var,'k')
    plot(model_var,'r')
    subplot(2,3,4); hold on;
    plot((R-Rmean)')
    subplot(2,3,5); hold on;
    plot((R-Rm)')
    subplot(2,3,6); hold on;
    plot(pVar, 'k','linewidth',2)


    results.var_explained(:,celldex) = pVar(1:length(t0s));
end




