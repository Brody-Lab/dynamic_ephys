function out = rows(sph)

out = size(sph, 1);
