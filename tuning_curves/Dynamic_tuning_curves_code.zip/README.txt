This folder contains my code for my updated tuning curve method. This code has been archived mid-project in a rather hurried fashion, so I apologize. It will take a bit of work on your part to adapt the pipeline to your task and data. 

Start in the file "build_tuning_curves.m" which extracts a list of cells and then loads/computes the tuning curve for each cell. 
